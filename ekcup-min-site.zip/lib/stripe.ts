import Stripe from 'stripe'
export const stripe=new Stripe(process.env.STRIPE_SECRET_KEY||'',{apiVersion:'2024-09-30.acacia'})
export const PRICE_IDS={ONETIME:process.env.NEXT_PUBLIC_STRIPE_PRICE_ONETIME||'',MONTHLY:process.env.NEXT_PUBLIC_STRIPE_PRICE_MONTHLY||''}
