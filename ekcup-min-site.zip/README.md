Install deps, copy .env.example to .env.local, set Stripe keys & price IDs, then run: npm run dev
