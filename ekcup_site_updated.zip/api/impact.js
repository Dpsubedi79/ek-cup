const Stripe = require("stripe");

module.exports = async (req, res) => {
  if (req.method !== "GET") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const secretKey =
      process.env.STRIPE_SECRET_KEY ||
      process.env.STRIPE_SECRET ||
      process.env.STRIPE_KEY;

    if (!secretKey) {
      console.error("Missing STRIPE_SECRET_KEY in environment.");
      res
        .status(500)
        .json({ error: "Stripe secret key is not configured on the server." });
      return;
    }

    const stripe = Stripe(secretKey);

    const goalEnv =
      process.env.DONATION_GOAL_USD || process.env.DONATION_GOAL || "1000";
    const goalTargetUSD = Number(goalEnv) || 1000;
    const volunteerHours = Number(process.env.VOLUNTEER_HOURS || 0);

    let totalCents = 0;
    let hasMore = true;
    let startingAfter = null;

    // Aggregate all successful USD payment intents
    while (hasMore) {
      const page = await stripe.paymentIntents.list({
        limit: 100,
        ...(startingAfter ? { starting_after: startingAfter } : {}),
      });

      for (const pi of page.data) {
        if (pi.status === "succeeded" && pi.currency === "usd") {
          // Prefer amount_received, fallback to amount
          totalCents += pi.amount_received || pi.amount || 0;
        }
      }

      hasMore = page.has_more;
      if (hasMore && page.data.length > 0) {
        startingAfter = page.data[page.data.length - 1].id;
      }
    }

    const totalUSD = Math.round(totalCents / 100);

    // Simple impact model – you can tweak these later
    const cups = totalUSD * 12; // e.g. ~$1 ≈ 12 cups of food
    const families = Math.max(0, Math.floor(totalUSD / 40)); // every ~$40 helps a family
    const warmth = totalUSD * 3; // e.g. blankets, jackets, etc.

    res.status(200).json({
      totalDonatedUSD: totalUSD,
      goalTargetUSD,
      cups,
      families,
      warmth,
      volunteerHours,
    });
  } catch (err) {
    console.error("Impact API error:", err);
    res.status(500).json({ error: "Failed to load impact totals." });
  }
};
