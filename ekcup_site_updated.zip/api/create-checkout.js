const Stripe = require("stripe");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const secretKey =
      process.env.STRIPE_SECRET_KEY ||
      process.env.STRIPE_SECRET ||
      process.env.STRIPE_KEY;

    if (!secretKey) {
      console.error("Missing STRIPE_SECRET_KEY in environment.");
      res
        .status(500)
        .json({ error: "Stripe secret key is not configured on the server." });
      return;
    }

    const stripe = Stripe(secretKey);

    let body = req.body || {};
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch (e) {
        body = {};
      }
    }

    const { amount, frequency } = body;

    const numAmountDollars = Number(amount);
    const amountInCents = Math.round(numAmountDollars * 100);

    if (!amountInCents || amountInCents <= 0) {
      res.status(400).json({ error: "Invalid amount." });
      return;
    }

    const freq = frequency || "one_time";

    const origin =
      req.headers.origin ||
      (req.headers.host ? `https://${req.headers.host}` : null);

    const baseUrl = origin || "https://ekcup.org";

    const successUrl = `${baseUrl}/?success=true`;
    const cancelUrl = `${baseUrl}/?canceled=true`;

    let sessionConfig;

    if (freq === "one_time") {
      // One-time donation
      sessionConfig = {
        mode: "payment",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "EK Cup Foundation Donation",
              },
              unit_amount: amountInCents,
            },
            quantity: 1,
          },
        ],
        success_url: successUrl,
        cancel_url: cancelUrl,
      };
    } else {
      // Recurring donation
      let interval = "month";
      let intervalCount = 1;

      if (freq === "weekly") {
        interval = "week";
      } else if (freq === "biweekly") {
        interval = "week";
        intervalCount = 2;
      } else if (freq === "monthly") {
        interval = "month";
      }

      sessionConfig = {
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "EK Cup Foundation Recurring Donation",
              },
              unit_amount: amountInCents,
              recurring: {
                interval,
                interval_count: intervalCount,
              },
            },
            quantity: 1,
          },
        ],
        success_url: successUrl,
        cancel_url: cancelUrl,
      };
    }

    const session = await stripe.checkout.sessions.create(sessionConfig);
    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error("Create checkout error:", err);
    res
      .status(500)
      .json({ error: "Failed to create checkout session. Please try again." });
  }
};
