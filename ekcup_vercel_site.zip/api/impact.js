const Stripe = require("stripe");

module.exports = async (req, res) => {
  if (req.method !== "GET") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
    const goalTargetUSD = Number(process.env.DONATION_GOAL_USD || 1000);
    const volunteerHours = Number(process.env.VOLUNTEER_HOURS || 0);

    let totalCents = 0;
    let hasMore = true;
    let startingAfter = null;

    while (hasMore) {
      const charges = await stripe.charges.list({
        limit: 100,
        status: "succeeded",
        ...(startingAfter ? { starting_after: startingAfter } : {}),
      });

      for (const ch of charges.data) {
        if (ch.currency === "usd") {
          totalCents += ch.amount;
        }
      }

      hasMore = charges.has_more;
      if (hasMore) {
        startingAfter = charges.data[charges.data.length - 1].id;
      }
    }

    const totalUSD = totalCents / 100;
    const cups = Math.floor(totalUSD / 5);
    const families = Math.floor(totalUSD / 20);
    const warmth = Math.floor(totalUSD / 10);

    res.status(200).json({
      totalDonatedUSD: totalUSD,
      goalTargetUSD,
      cups,
      families,
      warmth,
      volunteerHours,
    });
  } catch (err) {
    console.error("Impact API error:", err);
    res.status(500).json({ error: "Failed to load impact totals." });
  }
};
