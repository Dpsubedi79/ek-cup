const Stripe = require("stripe");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
    const { amount, frequency } = req.body || {};

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      res.status(400).json({ error: "Invalid amount." });
      return;
    }

    const freq = frequency || "one_time";

    const origin = req.headers.origin || "https://ekcup.org";
    const successUrl = `${origin}/?success=true`;
    const cancelUrl = `${origin}/?canceled=true`;

    let sessionConfig = {
      mode: "payment",
      success_url: successUrl,
      cancel_url: cancelUrl,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Donation to EK Cup Foundation",
            },
            unit_amount: Math.round(numAmount * 100),
          },
          quantity: 1,
        },
      ],
    };

    if (freq !== "one_time") {
      let interval = "month";
      let interval_count = 1;

      if (freq === "weekly") {
        interval = "week";
      } else if (freq === "biweekly") {
        interval = "week";
        interval_count = 2;
      } else if (freq === "monthly") {
        interval = "month";
      }

      sessionConfig = {
        mode: "subscription",
        success_url: successUrl,
        cancel_url: cancelUrl,
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "Recurring Donation to EK Cup Foundation",
              },
              recurring: {
                interval,
                interval_count,
              },
              unit_amount: Math.round(numAmount * 100),
            },
            quantity: 1,
          },
        ],
      };
    }

    const session = await stripe.checkout.sessions.create(sessionConfig);
    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error("Create checkout error:", err);
    res.status(500).json({ error: "Failed to create checkout session." });
  }
};
